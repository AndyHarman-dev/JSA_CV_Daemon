# Handoff: Manual Job Launch + `--select-language` Boot Sequence

## Overview
Two changes to the JSA daemon UI, both aimed at the same root problem: **JSA currently auto-starts every scraped job immediately on `run`, so a user never gets a chance to pick an output language before the CV/cover-letter generation kicks off.**

1. **Manual per-job launch.** Jobs no longer appear pre-running. Freshly scraped jobs sit in a "Queued — Not Started" state until the user explicitly clicks LAUNCH on that job's row.
2. **`--select-language` boot sequence.** When the CLI is invoked with `--select-language`, before the normal dashboard appears the user is shown a full-screen language picker, then a terminal-style "boot log" animation, and only then is dropped into the regular app. This is a second, earlier opportunity to set the language — before any job launches at all.

Backend/CLI work (actually not auto-starting jobs, wiring the `--select-language` flag, persisting the chosen language into the generation pipeline) is **out of scope of this package** — it's for the engineer implementing this, not something designed here.

## About the Design Files
The bundled `.dc.html` files are **design references built as interactive HTML/React prototypes** — not production code to copy directly. They render live and are fully clickable (open in a browser) so you can see exact timing and easing. The task is to recreate this behavior in JSA's real frontend stack using its existing component patterns, not to ship this HTML as-is.

## Fidelity
**High-fidelity.** Colors, type, spacing, corner treatments, and animation timings below are final — implement them as specified using your codebase's actual design tokens/components where they already exist (e.g. if JSA already has a button component, badge component, etc., use those rather than rebuilding from scratch).

## Screens / Views

### 1. Job row — Queued state (`JSA App Shell.dc.html`)
- Jobs start in state `pending`. They render in their own top-most sidebar group, **"Queued — Not Started"**, so they're not buried among running/review jobs.
- Row: company name (13.5px/600 IBM Plex Sans), role (11.5px/400, muted), tier badge (`T` + A/B/C, monospace, color-coded — A = green `#8FE3A0`, B = cyan `#33E6E6`, C = muted gray `#4D5868`).
- Right-aligned control replaces the usual status badge: a solid pill button, background `#F4CE4A` (accent gold), text `#06080B`, `600 10px "Chakra Petch"`, letter-spacing `.04em`, small play-triangle icon + label `LAUNCH`. Border-radius follows the row's corner style (chamfered in "hud" skin, ~2–3px radius in "terminal" skin).

### 2. Job row — Launching transition
- On click: button becomes a pill in the same slot showing a 6px spinning ring (border-top transparent, 0.6s linear rotation) + label `LAUNCHING`, colored gold, sunk background.
- After **150ms**, the pill plays a "dematerialize" animation: `filter: blur(0→7px)`, `transform: scale(1→0.82)`, `opacity: 1→0`, over **380ms**, ease.
- Immediately when that finishes (total ~550ms after click), the job's underlying state flips from `pending` → `running` and the normal status badge (spinning dot, cyan, label `RUNNING`) fades in (`opacity 0→1`, translateY 4px→0, ~280ms ease) in the same slot. The button never "waits" for the job — visually it looks like the click itself launched the process, and the control disappears because there is nothing left to launch.
- No confirmation dialog. This is deliberately a single, low-friction click.

### 3. `--select-language` boot gate — language picker
- Full-viewport overlay, background = canvas dark (`#070A0F`), covers the entire app (`position: fixed; inset: 0`) until dismissed.
- Centered column: logo mark (30–34px chamfered gold square with a bolt icon) + wordmark "JSA // DAEMON" (700 17px "Chakra Petch", `//` in accent gold), a small caption "SELECT OUTPUT LANGUAGE BEFORE FIRST RUN" (500 11px "Share Tech Mono", letter-spacing `.14em`, muted gray, uppercase).
- Language options render as a wrapped row of pill buttons (5 shown in the prototype: English, Español, Français, Deutsch, 日本語 — extend to the full language list used elsewhere in the app). Selected pill: gold border + gold text + faint gold-tinted background. Unselected: neutral border, muted text.
- Primary action button below: "CONFIRM & BOOT", solid gold, `#06080B` text, bolt icon, `600 13px "Chakra Petch"`.

### 4. `--select-language` boot gate — terminal boot log
- Replaces the language picker in the same full-screen overlay once confirmed.
- Header line: server icon + "JSA_DAEMON // BOOT SEQUENCE" in gold, monospace, uppercase, letter-spacing `.14em`.
- Below it, boot lines print one at a time (see exact copy below), each prefixed with a cyan `>`, monospace 13px, muted ink color, each new line fades in (~200ms ease). A blinking block cursor (`█`, 1s step-start infinite opacity blink) sits after the last printed line.
- Progress bar underneath: 6px track, sunk background, gold fill, plus a right-aligned percentage readout (monospace).
- **Boot copy, in order** (last line's bracket text is a stand-in for the actually-selected language, uppercased):
  1. `daemon.init() … OK`
  2. `loading module registry … OK`
  3. `connecting backend: CLAUDE CLI … OK`
  4. `mounting job queue store … OK`
  5. `restoring scratch buffer … OK`
  6. `applying locale pack: {SELECTED_LANGUAGE} … OK`
  7. `verifying output/ directory … OK`
  8. `starting workers [1/5 .. 5/5] … OK`
  9. `daemon ready.`
- Total boot duration ≈ **2.3 seconds**, driven by elapsed wall-clock time (not a fixed per-line delay — see Interactions note below on why this matters). On completion, hold for ~500ms then dismiss the overlay, revealing the normal app shell underneath (already mounted, so this reads as "booting into" the dashboard rather than a page navigation).

## Interactions & Behavior
- **Timing must be elapsed-time-based, not tick-counted.** The prototype's first implementation incremented a line counter once per `setInterval` tick; under any timer throttling (backgrounded tab, low-power mode, etc.) it could stall indefinitely and never complete. The fix: each tick computes `pct = min(100, elapsed / totalDuration)` from a stored start timestamp, and derives how many lines to show from that percentage — so a late-firing tick still snaps to the correct (possibly-100%) progress instead of requiring every single tick to have fired. Implement the real boot sequence the same way: derive progress from elapsed time, not from counting fired timers/frames.
- Launch button click has no separate confirmation step — treat this as intentional; don't add one unless product asks for it.
- The language picker requires an explicit "CONFIRM & BOOT" click; there's no auto-advance or timeout.
- This boot gate should only appear when the CLI was invoked with `--select-language`. Without the flag, the app should go straight to the dashboard (this is the prototype's default with the gate off).

## State Management
Reference implementation used this shape (adapt to your app's actual state layer):
- `launchAnim: { [jobId]: 'arm' | 'exit' | undefined }` — transient per-job animation phase; cleared once the job flips to `running`.
- Job's real status: `pending → running` (fired ~550ms after the click, once the transient animation finishes).
- `bootStage: 'lang' | 'boot' | 'app'` — drives which of the three views renders; starts at `'lang'` only when `--select-language` was passed, otherwise starts at `'app'`.
- `bootLang: string` — currently selected language code, defaults to `'en'`.
- `bootLines: string[]`, `bootPct: number` — derived boot-log progress state, computed from elapsed time as described above.

## Design Tokens
- **Colors:** canvas `#070A0F`, surface `#10151D`, subtle `#0E141B`, sunk `#0B0F15`, border `rgba(140,190,210,.16)` / `rgba(140,190,210,.30)` (hover/emphasis), ink `#E8EEF2`, ink-muted `#8B97A6`, ink-faint `#4D5868`. Accent gold `#F4CE4A` (primary actions, launch, boot). Accent cyan `#33E6E6` (running/active state). Green `#8FE3A0` (tier A / success). Red `#FF4655` (danger/destructive). Violet `#9D7BFF` (review state).
- **Type:** display/headings — "Chakra Petch" (600/700). Body/UI — "IBM Plex Sans" (400–600). Monospace/system labels — "Share Tech Mono".
- **Radius:** sharp chamfered corners (12px corner cut) in "hud" skin variant; small 2–3px rounded corners in "terminal" skin variant (this app supports both — match whichever the existing codebase uses).
- **Animation durations:** launch arm phase 150ms; dematerialize 380ms ease; badge fade-in 280ms ease; boot total ≈2300ms; boot-line fade-in ~200ms ease; cursor blink 1s step-start infinite.

## Assets
No image assets. All icons are simple inline vector glyphs (bolt, play triangle, server, chevron, globe) — recreate as a small icon set or swap for the codebase's existing icon library at equivalent visual weight (1.5px stroke, rounded joins).

## Files
- `JSA App Shell.dc.html` — full app shell with both features wired in: job rows (`launchSlot`/`launchJob` methods), boot gate (`renderBootGate`/`renderBootLangPicker`/`renderBootLog`/`startBoot` methods), and the `selectLanguageMode` flag (maps to the CLI's `--select-language`).
- `Job Launch & Boot Sequence Options.dc.html` — earlier exploration file showing 3 launch-button variants and 2 boot-sequence variants; options **1a** (dematerialize launch) and **2a** (terminal boot log) are the ones that were chosen and implemented in the app shell above.
