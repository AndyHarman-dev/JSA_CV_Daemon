# Handoff: @-Mention Scratch-Note Dropdown

## Overview
A small addition to the existing job message box ("Type your answer…" / "Describe the revision you want…"): typing `@` opens a dropdown, anchored at the mouse cursor, listing the user's saved Scratch Buffer notes. Clicking a note pastes its full text into the message box at the cursor. The dropdown is read-only — no adding or editing notes from it.

## About the Design File
The bundled file (`JSA App Shell.dc.html`) is a **design reference built in HTML** — a working prototype demonstrating the intended look and interaction, not production code to copy verbatim. Recreate this behavior in the target codebase's existing environment (React, etc.) using its established component and state patterns.

## Fidelity
High-fidelity. Colors, spacing, typography, and interaction timing shown are final intent.

## Scope of this handoff
Only the @-mention dropdown feature is new. Everything else in the attached file (job queue, job detail, scratch buffer panel, structure editor handoff, etc.) is pre-existing and already implemented — do not rebuild it, reference it only for surrounding context/styling.

## Behavior

**Trigger**: While typing in the message textarea, if the user types `@`, the dropdown opens.

**Detection rule**: Scan backwards from the text cursor. If an `@` is found before any whitespace/newline, the mention is "active." If a space, tab, or newline is hit first, it is not active. This means:
- Typing more non-space characters after `@` keeps the dropdown open (no filtering of the list happens — it always shows all notes).
- Typing a space, or deleting the `@`, closes the dropdown.

**Position**: The dropdown opens anchored to the current mouse cursor position at the moment `@` is typed (tracked via a global `mousemove` listener, not the text-caret position). Once open, its position is locked — it does not follow the mouse while typing continues. Clamp position to stay within the viewport (8px margin, dropdown ~272px wide, up to 320px tall).

**Content**: Lists all Scratch Buffer notes, pinned notes first, then newest first (same sort as the Scratch Buffer panel). Each row shows the note's tag (e.g. `#salary`) and full text. Notes are **not editable and cannot be added** from this dropdown — it is display + insert only.

**Selection**: Clicking a note replaces the span of text from the triggering `@` through the current cursor position with `<note text> ` (trailing space added), then returns focus to the textarea with the cursor placed right after the inserted text.

**Empty state**: If the Scratch Buffer has no notes, show "No notes in buffer." in place of the list.

**Dismissal**: Closes when a note is selected, when the `@` is deleted, or when whitespace breaks the mention span (per the detection rule above). No explicit close button.

## Component Structure (from the reference file)

- `state.mentionOpen` (bool) — whether the dropdown is visible
- `state.mentionPos` ({x, y}) — pixel position where the dropdown is anchored, set once when the mention becomes active
- `state.mentionAt` (number|null) — index of the triggering `@` in the current draft text
- `state.mentionEnd` (number|null) — cursor index at the end of the active mention span, updated on every keystroke while active

Key logic (reference implementation, `JSA App Shell.dc.html`):
- `getMentionAt(text, cursor)` — the backward-scan detection rule described above
- `handleChatDraftChange(e)` — runs on the textarea's change/keyup/click; recomputes mention state; captures the mouse position (`this._lastMouse`, updated by a `window.mousemove` listener set up in `componentDidMount`) only at the moment the mention transitions from closed → open
- `insertScratchNote(entry)` — splices `entry.text + ' '` into the draft at `[mentionAt, mentionEnd)`, closes the dropdown, refocuses the textarea and restores the caret
- `renderMentionDropdown()` — renders the panel; uses `onMouseDown` + `preventDefault()` on each note row so the textarea's blur doesn't happen before the click's insert logic runs off already-captured state

## Visual Spec

- Panel: 272px wide, up to 320px max height, positioned `fixed`
- Background/border: matches the app's existing "surface" panel style (dark surface `#10151D`, 1px border `rgba(140,190,210,.16)`), same chamfered-corner treatment (8–10px notch) and corner-mark accents used elsewhere in the app, in the current accent color
- Header row: pin icon + "SCRATCH_BUFFER" label (mono font, 10px, letter-spacing .1em, uppercase) + right-aligned hint text "@ to paste" (9px mono, muted)
- Each note row: tag in accent mono color (9px) + note text (12px, sans, 1.45 line-height), full-width click target, subtle bottom divider, hover state matches other list rows in the app (`background:#1B232C` on hover)
- Fonts: UI text "IBM Plex Sans"; mono labels "Share Tech Mono"
- Empty state: centered italic muted text, 12px

## Assets
None beyond the existing inline icon set (simple stroke SVGs already defined in the reference component's `icon()` method — reuse the app's existing icon system, don't add new asset files).

## Files
- `JSA App Shell.dc.html` — full reference implementation. Search for `MENTION` in the file to jump to the relevant state, methods, and render function (`getMentionAt`, `handleChatDraftChange`, `insertScratchNote`, `renderMentionDropdown`).
- `screenshot-mention-dropdown.png` — the dropdown open over the message box, anchored at the mouse cursor.
