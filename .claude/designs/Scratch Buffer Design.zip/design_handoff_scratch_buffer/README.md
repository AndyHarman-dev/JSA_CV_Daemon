# Handoff: Scratch Buffer (Floating Notes Window)

## Overview
A persistent, cross-job scratch pad for the JSA daemon UI. Users capture recurring answers (salary floor, visa status, notice period, reusable blurbs, etc.) once and reuse them while reviewing any job — the notes are global to the user, not scoped to a single job.

This is framed as a "daemon process" surface (`SCRATCH_BUFFER`) consistent with the app's terminal/HUD visual language, not a generic notepad widget.

**Scope of this handoff:** ONLY the Scratch Buffer feature (the parked orb + floating capture/history window). The rest of the JSA app shell (header, job queue, job detail, review flow, etc.) is assumed to already exist in the target codebase, matching the attached reference. Do not rebuild the rest of the shell from this package — just add this one feature into it, wiring it up globally (mounted once, above/alongside the main app content, visible regardless of which job is selected).

## About the Design Files
The bundled HTML file (`JSA App Shell.dc.html`) is a **design reference prototype**, built as a self-contained authoring format for this tool — not production code to copy verbatim. Recreate the Scratch Buffer feature in the target codebase's real stack (React, Vue, native, etc.) using its existing component patterns, state management, and design tokens. The relevant logic lives in the methods prefixed `scratch*`/`renderScratch*` inside the `Component` class, plus a few lines wiring it into `componentDidMount`/`componentWillUnmount` and the root render tree — search the file for `SCRATCH_BUFFER` to find every touch point.

## Fidelity
**High-fidelity.** Colors, typography, spacing, icon shapes, and interaction behavior in the reference should be recreated pixel-for-pixel where they don't conflict with the codebase's existing design tokens (reuse the app's real tokens instead of hardcoding the hex values below if the codebase already defines equivalents).

## How It's Triggered
Two independent triggers, both toggling the same open/closed state:
1. **Click the parked orb** — a circular button fixed at `bottom: 22px; right: 22px` on the viewport (z-index above all app content, e.g. 70). Always visible, in every screen/state of the app.
2. **⌘+Space (Mac) / Ctrl+Space (Windows/Linux)** — global keydown listener, works from anywhere in the app (not just when a text field is focused elsewhere). Must `preventDefault()` so it doesn't collide with OS/browser shortcuts.

Additional close behavior:
- **Esc** closes the window if it's open (does not affect anything else if closed).
- **Minimize button** (in the window's own header) closes the window back to the orb.
- Closing/minimizing never discards notes — it only hides the window. State (entries, draft text, window position) is preserved in memory and notes are also persisted to storage (see below).

On first open after a fresh mount, if the window has no remembered position yet, default it to roughly `top: 78px`, right-aligned with ~32px margin from the viewport's right edge (i.e. `left = window.innerWidth - 320`). After that, its position is whatever the user last dragged it to (see Drag below) — kept only for the session, not persisted to storage.

## How Notes Persist
- Storage: `localStorage`, key `jsa_scratch_entries`, value = JSON array of entry objects (see Data Model). Swap for the codebase's real persistence layer (API call, IndexedDB, account-scoped backend store, etc.) if one exists — the important semantic is: **notes belong to the user, not to any single job, and survive reloads/navigation/switching jobs.**
- On mount, load entries from storage. If none exist yet (first run), seed with 2–3 example entries so the feature isn't confusingly empty (optional — a real product may prefer to start empty with placeholder copy instead; ask design/PM).
- Every mutation (add, pin/unpin, delete) writes the full updated array back to storage immediately — no separate "save" action.
- Notes are never scoped/filtered by which job is currently open. Same list everywhere.

## Data Model
Each entry:
```
{
  id: string,        // unique, e.g. `e${Date.now()}`
  text: string,       // the note body, user-typed
  tag: string,        // auto-derived short label, see "Tag inference" below
  pinned: boolean,    // user-toggleable, pinned entries float to top
  ts: number          // Date.now() at creation, used for relative time + sort
}
```
**Tag inference** (best-effort, cosmetic only — not a hard categorization system): if the typed text starts with `#word`, use that literally as the tag. Otherwise pattern-match on keywords: "salary"/"comp" → `#salary`, "visa"/"sponsor" → `#visa`, "notice" → `#notice`; anything else falls back to `#note`.

**Sort order** in the feed: pinned entries first, then by `ts` descending (most recent first) within each group.

**Relative time label**: `<1h` → `"Nm"` (minutes, min 1), `<24h` → `"Nh"`, else `"Nd"`.

## Layout & Components

### 1. Orb (resting/closed state)
- Fixed position, `bottom: 22px`, `right: 22px`, size 46×46px, circular (or the app's "chamfered" corner style if `skin === 'hud'` — see Design Tokens).
- Background: app surface color; 1px border in a tinted accent border color; icon (pin/thumbtack glyph, 18px) centered, colored in the accent color.
- Drop shadow: soft dark shadow plus a subtle accent-colored glow (`0 6px 24px rgba(0,0,0,.5), 0 0 18px <accent>44`).
- **Badge**: small circular counter (16px, accent background, dark text, ~9px bold monospace) pinned to the top-right corner of the orb, showing the total entry count. Hidden when count is 0.
- Tooltip/title: "Scratch buffer (⌘ + Space)".

### 2. Floating window (open state)
- Fixed position (draggable — see below), width 288px, max-height `min(70vh, 460px)`, flex column, internal scroll only in the entries list (header/input/footer stay fixed).
- Semi-transparent surface background with backdrop blur (`~94% opacity surface color + 8px blur`), 1px accent-tinted border, rounded corners (10px, or chamfered corner-cut style in "hud" skin), strong drop shadow plus faint accent glow ring.
- **Header row** (drag handle): 8–10px padding, bottom border. Contains, left to right: a small "move/drag" icon (muted color, cursor: grab), a small pulsing accent dot (breathing glow, ~2.4s ease-in-out cycle), the label "SCRATCH_BUFFER" (monospace, small-caps letterspacing, semibold), the live entry count (muted, monospace), and a minimize button (small "–" icon) on the far right that closes the window.
  - Entire header is the drag surface except the minimize button itself.
- **Quick-capture input row**: directly below the header, subtly darker background, bottom border. A small "+" icon, then a single-line text input (transparent background, monospace font, placeholder `"quick note… (Enter to log)"`), then a small "↵" keycap hint on the right. Pressing Enter with non-empty text creates a new entry (see Data Model), clears the input, and the new entry appears at the top of the feed (unless something else is pinned above it). Empty submissions are ignored.
- **Entries feed**: scrollable list, most recent/pinned on top (see Sort order). Each row: relative-time label (fixed-width, muted, monospace) · tag (accent-cyan, monospace, small) · note text (regular UI font, wraps) · pin toggle button (fills accent color when pinned, muted outline otherwise) · delete (×) button (muted, appears functional on hover in a real build — can be always-visible or hover-revealed, designer's call). Rows separated by a hairline border.
  - Empty state (no entries at all): centered italic muted text, "No notes yet — type above."
- **Footer strip**: thin, muted, monospace microcopy: "Persists across all jobs · ⌘+Space to toggle".

### Drag behavior
- Mousedown on the header (excluding the minimize button) starts a drag: track the pointer's movement delta from the mousedown point and add it to the window's position-at-drag-start, on every `mousemove`, until `mouseup`. Clamp so the window can't be dragged fully off-screen (minimum ~8px stays visible on the left/top edges in the reference — extend this to all four edges in production).
- Cursor: `grab` at rest on the header, conventionally `grabbing` while active (reference doesn't swap the cursor mid-drag; do so in production for polish).

## Interactions & Behavior Summary
- Orb click → open window (if it has no stored position yet, place it near top-right under the header).
- ⌘/Ctrl+Space anywhere in the app → toggle window open/closed; when opening this way, also autofocus the quick-capture input.
- Esc → close window (only when open; do not swallow Esc globally when closed).
- Enter in the input (non-empty) → commit a new entry, clear input, keep focus in input.
- Click pin icon on a row → toggle that entry's `pinned` flag, re-sorts the list.
- Click × on a row → delete that entry immediately (reference has no confirmation step — add one if the target product wants extra safety against accidental deletes).
- Minimize button or Esc → hide window, state and storage untouched.
- Dragging the header → reposition the window; position kept only for the current session (not written to storage).

## Design Tokens
Reuse the host app's existing tokens; the reference prototype uses this palette (accent is themeable — sampled here as amber):
- Accent: `#F4CE4A` (also supports cyan `#33E6E6`, red `#FF4655`, magenta `#FF2BD6` as alternate themes)
- Accent-cyan (used for tag text specifically): `#33E6E6`
- Surface: `#10151D` · Sunken/input background: `#0B0F15` · Canvas/app background: `#070A0F`
- Border (hairline): `rgba(140,190,210,0.16)`; stronger border variant: `rgba(140,190,210,0.30)`
- Text primary: `#E8EEF2` · Text secondary: `#8B97A6` · Text tertiary/muted: `#4D5868`
- Fonts: UI text — "IBM Plex Sans"; monospace (labels, timestamps, tags, keycaps) — "Share Tech Mono"; display/headings — "Chakra Petch" (not used inside this feature's own copy, only inherited context)
- Corner style: two supported skins — `terminal` (rounded corners, ~2–10px radius depending on element) and `hud` (flat chamfered/cut corners via CSS `clip-path` polygon, radius 0). The Scratch Buffer should respect whichever skin the rest of the app is in.
- Shadows: window — `0 24px 60px rgba(0,0,0,.6), 0 0 0 1px <accent>22`; orb — `0 6px 24px rgba(0,0,0,.5), 0 0 18px <accent>44`

## Assets
No external image assets. All icons are inline stroke-based SVGs (16×16 viewBox, ~1.5px stroke, round caps/joins) — pin/thumbtack, move/drag (4-way arrow cross), plus, minus, and close (×). Recreate as an icon set or swap for the codebase's existing icon library if equivalents exist (pin, drag-handle, plus, minus/collapse, close).

## Files
- `JSA App Shell.dc.html` — full app shell reference; search for `SCRATCH_BUFFER` to find all Scratch Buffer–related state, methods, and render code within the single `Component` class. Key methods: `loadScratchEntries`, `saveScratchEntries`, `guessTag`, `toggleScratch`, `addScratchEntry`, `togglePinEntry`, `deleteScratchEntry`, `scratchTimeLabel`, `startScratchDrag`, `renderScratchOrb`, `scratchEntryRow`, `renderScratchWindow`, `renderScratchBuffer`.
