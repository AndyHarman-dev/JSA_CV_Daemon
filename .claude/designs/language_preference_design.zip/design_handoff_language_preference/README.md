# Handoff: Language Preference

## Overview
A global **output language** setting for JSA. The user picks a language once; from then on
(a) every LLM-authored deliverable — CV JSON, cover-letter JSON, the agent's clarifying
questions and change-logs — is produced in that language, and (b) the app's own UI chrome
(labels, empty states, button text) is relabeled to match. The control lives in the CV
Structure Editor's top bar, next to RUN INFERENCE / RE-RUN / COMMIT, as a globe pill that
opens a searchable dropdown over a curated, **config-driven** list of ~20 languages.

This is explicitly a **two-sided feature**: a frontend control plus a backend pipeline
change. Implementing only the dropdown does nothing on its own — the value it sets has to
reach `jsa/pipeline/stages.py` and change what gets sent to the model. That backend half is
the harder, more important part of this handoff; read the "Pipeline Integration" section
before starting.

## About the Design Files
The files in this bundle are **design references built in HTML** (Claude "Design
Components" — they render via `React.createElement` inside a bespoke prototyping runtime,
not real JSX). They are not production code to copy directly.

- **`Language Preference Options.dc.html`** — three placement explorations (toolbar
  dropdown, inline identity chip, persistent-badge-plus-overlay). Kept for context on the
  alternatives considered; **the toolbar dropdown ("1a") is the one selected and specced
  below.**
- **`CV Structure Editor.dc.html`** — the full CV Structure Editor screen with the chosen
  language pill wired into its top bar and a live demo of chrome-string translation. This
  is the fidelity reference for the actual implementation task.

The task is to **recreate this control inside the existing JSA frontend**
(`JSA/frontend/` — React 18 + TypeScript + Vite + Tailwind, Zustand store, the
`theme/tokens.ts` dark "daemon" theme) and to **wire it through the existing FastAPI +
SQLAlchemy backend** (`JSA/jsa/`), following the patterns already established there (see
below). Do not ship the HTML, and do not use `React.createElement`-style construction —
build normal JSX components matching the house style visible in
`src/components/Header.tsx`, `JobDetail.tsx`, `ReviewPane.tsx`.

## Fidelity
**High-fidelity for the control itself** (colors, spacing, typography, interaction — match
closely, tokens below). **Low-fidelity / illustrative for chrome translation** — the
prototype hardcodes 5 languages' worth of copy for ~11 strings as a proof of concept; real
coverage (which strings, which languages, how translations are authored/maintained) is a
product decision the team should make, not something to lift verbatim from the prototype.

---

## Why this needs backend work, not just a frontend dropdown
The dropdown's value must change **what the LLM pipeline sends the model**, in
`jsa/pipeline/stages.py`. Today, `_get_system_prompt(stage)` returns a static prompt file
verbatim (`jsa/prompts/loader.py` → `PROMPT_CDADJUST.md`, `CVL_PROMPT.md`,
`PROMPT_FIT_ASSESSMENT.md`, `PROMPT_INFER_STRUCTURE.md`) with no templating, and
`_build_initial_user_msg()` assembles the first user turn from job text + research +
the base CV structure. Neither knows about language at all. Making the dropdown "do"
anything requires a plumbing change through this exact path. See **Pipeline Integration**
below for the precise change.

## Screens / Views

### CV Structure Editor top bar (the only screen touched)
Reference: `CV Structure Editor.dc.html`, `renderTopbar()` / `renderLangPill()`.

- **Layout:** existing top bar, unchanged — `display:flex; justify-content:space-between;
  padding:10px 18px`, `background: rgba(10,14,19,.85)` with `backdrop-filter: blur(10px)`,
  `border-bottom: 1px solid rgba(140,190,210,.16)`. The language pill is a **new item**
  inserted into the existing right-hand button cluster, directly **before** the
  RE-RUN/RUN INFERENCE button (so reading order is: `[SRC.JSON] [🌐 EN ▾] [RE-RUN]
  [COMMIT]`).

- **Pill (closed state):**
  - Inline-flex, `gap:7px`, `padding:7px 11px`, `border:1px solid rgba(140,190,210,.30)`,
    `border-radius:2px` (terminal skin) / `7px` (hud skin — this app runs hud, see tokens),
    `background:#10151D` (`T.surface`), text color `#E8EEF2` (`T.ink`).
  - Contents, left to right: a globe glyph (`T.a` accent color, 13px), the **current
    language code** uppercased in mono font at 11px/600 weight/`.04em` tracking (e.g.
    `EN`), a chevron (`T.ink3`) that rotates 180° when open.
  - Hover: `background:#1B232C` (existing `.cvghost`/`.cvbtn` hover, reuse the class).

- **Panel (open state):** anchored `top:100%; right:0; margin-top:6px`, width `260px`,
  same panel chrome as the existing add-section / download menus (`panelBase()` —
  surface background, `1px solid rgba(140,190,210,.30)` border, corner-mark accents,
  `box-shadow: 0 10px 32px rgba(0,0,0,.55)`), `z-index:40`.
  - Header row: `"LANGUAGE · OUTPUT + UI"` (translated label), mono 9.5px/600,
    `.12em` tracking, uppercase, `color:T.ink3`.
  - Search box directly under the header: sunk background (`#0B0F15`), 1px border, a
    search-glyph + text input, placeholder `"Search languages…"`. Filters on code, English
    name, and native name (case-insensitive substring).
  - Scrollable list, `max-height:240px`. Each row: language code (mono, 9.5px/600, 22px
    fixed width), English name (14px/500, flex:1), native name (right-aligned-ish,
    11.5px/400, `T.ink3`), and a checkmark on the currently-selected row. Selected row gets
    a faint accent-tinted background (`color-mix(in srgb, accent 14%, surface)`).
  - Footer note: `"Applies to LLM output and app labels everywhere."` (11px, `T.ink3`,
    top border).
  - Clicking a row sets the language and **closes the panel** (no separate "Apply" step —
    consistent with how every other control in this app is instant/no-save-button).

- **What visibly changes when a language is picked** (proof-of-concept scope in the
  prototype — expand deliberately, see "Chrome translation scope" below):
  - Top-bar sub-label ("STRUCTURE_ENGINE · LIVE SYNC" → localized).
  - Identity strip's "OPERATOR" / "MODULES" labels.
  - "SRC.JSON"/"HIDE SRC", "RE-RUN"/"RUN INFERENCE", "COMMIT" button labels.
  - The empty-state headline, body copy, and "INIT BLANK" button.

## Interactions & Behavior
- **Open/close:** click the pill to toggle the panel; click a language row to select +
  close; no explicit close button (click-outside-to-close should be added in production —
  the prototype omits it for simplicity).
- **Search:** plain substring filter, live as you type, matches code/English name/native
  name. Empty result state: `"No matches."` centered, italic, muted.
- **No confirmation step.** Selecting is the commit — matches the rest of the app (e.g.
  accent/skin/density tweaks apply immediately).
- **Persisted, not per-session.** This is a **global** app preference (see Data Model),
  not tied to one job or one browser tab — reflect that in code by driving it from a
  top-level store synced with the backend, not local component state.
- No loading/error states are needed for the dropdown itself; the preference read/write is
  a small, fast, local JSON round-trip (see below) — treat a failed PUT as a toast/log, not
  a blocking state.

## State Management

### Frontend
Add to the existing Zustand `useStore` (`src/store.ts`), alongside `wsStatus`,
`editorOpen`, etc. — do **not** create a separate store, this is app-global exactly like
those:
```ts
language: string;              // ISO 639-1 code, e.g. "en" — hydrated from GET /api/preferences on boot
setLanguage(code: string): void; // optimistic set + PUT /api/preferences, revert on failure
```
Hydrate once on app mount (alongside the existing `api.config()` call pattern in
`App.tsx`/wherever startup fetches happen). Every component that renders translatable
chrome reads `language` from the store (or a thin `useT()` hook built on top of it) so a
change re-renders everywhere reactively — there is precedent for this cross-cutting-signal
shape already in the store (`lastBackendSwitch`).

### Backend
Treat this exactly like the existing **base-CV structure** pattern
(`jsa/store/cv_structure.py` + `jsa/api/routes_cv_structure.py`) — a single-file JSON
store, not a DB table (it's one global value, not per-job data):

- New `jsa/store/preferences.py`: `load(settings) -> Preferences`, `save(settings,
  prefs)`, `read(path) -> Preferences` (path-based variant for stage-time reads, mirroring
  `cv_structure.read()`). Defaults to `{"language": "en"}` when the file doesn't exist yet
  — no 404/empty-state needed on the frontend (unlike CV structure, there's always a valid
  default).
- New `Settings.preferences_path` property, derived from `db_path` the same way
  `cv_structure_path` is.
- New routes in a `jsa/api/routes_preferences.py` (or fold into `routes_meta.py`):
  - `GET /api/preferences` → `{"language": "en"}`
  - `PUT /api/preferences` → body `{"language": "es"}`, validates the code against the
    server-side language catalog (see below), 422 on an unknown code, persists, returns
    the stored value.
- **Read at stage time, not at server-startup**, exactly like `cv_structure_path` is read
  fresh in `run_stage()` — so a language change takes effect on the **next** job/stage run
  without a server restart, and (importantly) does **not** change the language mid-way
  through an already-open agent session (see Pipeline Integration).

### One shared language catalog — do not fork the list
The picker's ~20-language list is **config-driven** (a single array of `[code, English
name, native name]`, see the prototype's `LANGS`). Define it **once**, server-side (e.g.
`jsa/i18n/languages.py`), and serve it to the frontend via `/api/config` (add a
`languages` key) rather than hand-copying the same array into the TS codebase — the PUT
validation and the dropdown's options must never drift apart.

---

## Pipeline Integration (the part that isn't just a frontend dropdown)

This is the crux of the feature. Everything here lives in `jsa/pipeline/stages.py`,
`jsa/prompts/`, and touches `jsa/schema/cv.py` and `jsa/schema/cover_letter.py` only as a
**hard constraint to respect**, not to change.

### 1. Inject a language directive into the system prompt
`_get_system_prompt(stage)` currently returns `loader.read_prompt(...)` verbatim. Change
its call sites to also take the current language (read via `preferences.read(prefs_path)`,
passed down the same way `cv_structure_path` already is threaded through `run_stage(...)`),
and append a short directive to the loaded prompt text, e.g.:

```
## Output language
Write all natural-language, user-facing output in {language_name} ({language_code}) —
the change-log, any clarifying questions you ask, and every text VALUE in the final
JSON (summary prose, bullet text, headings, cover-letter paragraphs). Do not translate
JSON **keys**/field names — they are fixed schema fields and must stay exactly as
specified (`heading`, `subheading`, `bullets`, `text`, `items`, `entries`, etc.).
```

Apply this to **all four** stages (`cv_adjust`/`revising_cv`, `cover_letter`/
`revising_cl`, `fit_assessment`, `infer_structure`) — an operator who set Japanese expects
the agent's clarifying questions and the fit-assessment reason to be in Japanese too, not
just the final CV.

### 2. Hard constraint: don't let the model translate what the code parses
Several stages parse the model's raw reply with English-only string/regex logic. The
language directive **must carve these out explicitly** or the pipeline breaks silently:

- **`fit_assessment`**: `_parse_fit_verdict()` in `stages.py` matches the literal
  substrings `"FIT"` / `"UNFIT"` at the start of the first line. The directive for this
  stage must say: *"the verdict word itself (`FIT` or `UNFIT`) must stay in English and be
  the first word of your reply; only the reason that follows should be in
  {language_name}."*
- **JSON field names**: `CVDocument`/`Section`/`Entry`/`CoverLetter` (in
  `jsa/schema/cv.py`, `cover_letter.py`) classify content by **exact key name**
  (`_HEADING_KEYS`, `_BULLET_KEYS`, etc. — see the module docstring's "Robustness model").
  Translating a key name (e.g. writing `"encabezado"` instead of `"heading"`) would not
  raise an error — the tolerant `_Loose`/`extra="ignore"` schema would just silently drop
  that field's content. This is the single most important thing to get right: **only
  string VALUES translate, never keys.**
- **Sentinel blocks** (`<<<FINAL>>>`, `<<<NEED_INPUT>>>`, `<<<END>>>`) must stay in
  English/ASCII exactly as spelled — they're matched literally by
  `jsa/agents/protocol.py`.

### 3. Known gap to flag, not silently ship around
`jsa/schema/cv.py`'s `_not_a_cover_letter` content-kind guard
(`_LETTER_FORMULA_RE`) detects a cover-letter-shaped payload in the CV stage by matching
**English** phrases ("dear hiring", "sincerely,", etc.). Once CV output can be in Spanish,
Japanese, etc., this guard goes blind for non-English output — a Spanish cover letter
mistakenly emitted as the CV would sail through undetected. This is a **real regression
risk**, not a nice-to-have: raise it with the team. Two reasonable fixes (either is
out of scope for a first cut, but should be a fast-follow, not silently ignored):
  (a) maintain per-language formula lists, or (b) run the guard on a to-English
  gloss step. Do not ship non-English CV output without at least a written decision on
  this.

### 4. Where the language actually comes from at generation time
`run_stage()` already threads `cv_structure_path` in from the orchestrator/caller down to
where `_build_initial_user_msg` is assembled — thread `preferences_path` (or the resolved
language string) the same way, and resolve it in the **same fresh, no-cache, read-at-stage-
time manner** as `cv_structure.read()` — the docstring rationale ("edits apply to the next
job without a restart") applies identically here.

### 5. Do not change language mid-conversation
A `restore_session`/resume path (awaiting_input answer, a revision) continues an
**already-open** model session/history. Do not re-inject a *changed* language directive
into a resumed session — the model already committed to a language for that
conversation, and history replay would show a contradiction. Only **new** sessions
(`start_session`, i.e. the fresh branches in `run_stage()`) should pick up the
currently-saved preference. Document this explicitly in code — it's the same kind of
subtlety `_is_revision_resume()` already carefully handles for revision discrimination.

## Chrome translation scope (frontend)
The prototype hardcodes full copy for **English, Spanish, French, German, Japanese** for
exactly these 11 chrome strings, with every other catalog language silently falling back
to English:
`sub, operator, modules, srcJson, hideSrc, rerun, runInference, commit, emptyTitle,
emptyBody, initBlank`

This is illustrative, not a spec to ship as-is. Two open product questions the team should
settle before scaling this up, called out here rather than decided unilaterally:
1. **Coverage**: does "changes throughout the whole program" mean the entire frontend
   (every component's copy) or just the CV Structure Editor + JSA App Shell chrome shown
   here? The current React codebase (`Header.tsx`, `JobDetail.tsx`, `ReviewPane.tsx`, etc.)
   has hardcoded English strings scattered across ~15 components with no existing i18n
   layer — translating everything is a much bigger effort than this dropdown.
2. **Translation source**: hand-authored strings dictionary (like the prototype), a
   real i18n library (`react-intl`/`i18next`) with `.json` catalogs per locale, or
   LLM-generated-at-build-time strings — each has different tradeoffs for who maintains
   copy and how missing-translation fallback behaves.

Recommended incremental path: introduce the i18n plumbing (store field + `useT()` hook +
catalog file shape) now, ship it covering exactly the CV Structure Editor top bar +
empty-state (parity with this handoff), and expand catalog coverage as a follow-up
rather than blocking this feature on translating the whole app.

## Design Tokens
Reuses the existing "daemon" dark theme verbatim — no new tokens introduced.
- Accent (editor surface): `#FF4655` (`EDITOR_THEME.a` in `theme/tokens.ts`) — the globe
  glyph and selected-row tint use this.
- Fixed cyan "system" signal: `#33E6E6` — not used by this control, but is nearby in the
  identity strip; don't confuse with accent.
- Surface: `#10151D` · Subtle: `#0E141B` · Sunk (search box bg): `#0B0F15`
- Border: `rgba(140,190,210,.16)` · Border (stronger, panel outline): `rgba(140,190,210,.30)`
- Ink (primary text): `#E8EEF2` · Ink2 (secondary): `#8B97A6` · Ink3 (tertiary/labels): `#4D5868`
- Fonts: UI body `"IBM Plex Sans"`; mono (codes/labels) `"Share Tech Mono"`; display
  (buttons/headings) `"Chakra Petch"` — all already loaded by the app.
- Radius: this app runs the **hud** skin → `7px` on interactive chrome (not the sharp
  `2px` "terminal" skin radius also visible in the token file).
- Panel shadow: `0 10px 32px rgba(0,0,0,.55)`.

## Assets
No new image/icon assets. Two new inline SVG glyphs (16×16 viewBox, `strokeWidth:1.55`,
`round` caps/joins, matching every other icon in the app's `Icon.tsx`/icon-map pattern):
- **globe**: a circle + horizontal diameter line + two vertical ellipse arcs.
- **search**: a circle + a short diagonal handle line.
Reference `icon()` in `CV Structure Editor.dc.html` for exact path data.

## Files
- `Language Preference Options.dc.html` — the 3-option design exploration (context only).
- `CV Structure Editor.dc.html` — the fidelity reference with the chosen control
  implemented and wired to the empty-state/top-bar copy.
- `support.js` — prototyping runtime the `.dc.html` files depend on to open standalone in
  a browser; not relevant to the real codebase.

Real-codebase files referenced throughout this doc (for the developer's convenience,
not included in this bundle — read them from the actual repo):
`jsa/config.py`, `jsa/pipeline/stages.py`, `jsa/prompts/loader.py`,
`jsa/prompts/PROMPT_CDADJUST.md`, `jsa/schema/cv.py`, `jsa/store/cv_structure.py`,
`jsa/api/routes_cv_structure.py`, `jsa/api/routes_meta.py`,
`frontend/src/store.ts`, `frontend/src/api.ts`, `frontend/src/theme/tokens.ts`.
