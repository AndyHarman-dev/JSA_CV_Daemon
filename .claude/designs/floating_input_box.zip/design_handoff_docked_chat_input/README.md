# Handoff: Docked Chat Input (sticky-footer composer)

## Scope
This is a **narrow, single-mechanic handoff** — not the whole app. Implement only the docking/floating behavior of the chat composer (textarea + submit button) inside a scrollable panel. Ignore everything else in the referenced file (job list, headers, other panels, etc.) — it's included only as working context for this one mechanic.

## About the design file
`JSA App Shell.dc.html` (included in this folder) is an **HTML/React design reference**, not production code to copy verbatim. It's a Design Component authored in a proprietary internal format (inline-styled `React.createElement` calls, no JSX/build step). Recreate the mechanic below using your codebase's normal patterns (JSX + CSS-in-JS/Tailwind/CSS modules — whatever you already use), not by importing this file.

Relevant methods in the reference file: `chatBox()` (~line 723) and its caller context in `renderFollowUp()` (~line 685) / `renderReview()` (~line 731). The scrolling ancestor is the `<main style="overflow:auto">` element (~line 47), and the padded content column at ~line 680 (`padding: 20px 26px 80px`) is what establishes the horizontal bleed math below.

## Fidelity
High-fidelity. Exact CSS values below should be recreated pixel-for-pixel; adapt only the color tokens to your own theme.

## The mechanic

A chat composer (textarea + submit button) sits at the end of a scrollable panel (e.g. an agent message thread, a document review pane). Desired behavior:

1. **Short content:** if the panel's content fits without scrolling, the composer sits inline, directly after the content — no special treatment, no shadow, no gap.
2. **Long content:** once the panel's content overflows and becomes scrollable, the composer **docks to the bottom of the panel** (not the browser viewport) and stays pinned there while the content above scrolls underneath it. As you scroll up to read earlier content, the composer never moves off-screen.
3. This transition is **automatic and continuous** — there's no discrete breakpoint or JS-measured toggle. It must "just work" as content grows/shrinks (e.g. a streaming LLM response getting longer).
4. When docked, the composer reads as visually "elevated": a soft upward drop shadow, a top border, and a background that's a shade lighter than the page background (with a soft gradient fade at the very top edge so content doesn't cut off harshly underneath it).

## Implementation

This is achieved with **pure CSS `position: sticky` — no JS/scroll listeners required**. `position: sticky; bottom: 0` on the composer wrapper, inside the scrolling container, gives exactly the desired behavior for free: the browser only "sticks" the element once its natural flow position would otherwise scroll out of view at the bottom of the nearest scrolling ancestor. If content is short, the sticky element never leaves its natural document-flow position, so nothing looks docked.

Reference CSS (from the working prototype — adapt the color tokens):

```css
.chat-composer {
  position: sticky;
  bottom: 0;
  z-index: 8;

  /* bleed to the full width of the scroll container, ignoring the
     parent's horizontal padding, so the docked bar spans edge-to-edge */
  margin-left: -26px;
  margin-right: -26px;
  padding-left: 26px;
  padding-right: 26px;

  /* cancel the scroll container's bottom padding so the bar sits flush
     against the true bottom edge instead of floating above empty padding */
  margin-bottom: -80px;
  padding-top: 14px;
  padding-bottom: 20px;

  display: flex;
  flex-direction: column;
  gap: 8px;

  background: linear-gradient(rgba(7,10,15,0), #10151D 22%);
  border-top: 1px solid rgba(140,190,210,0.16);
  box-shadow: 0 -16px 28px -12px rgba(0,0,0,.5);
}
```

Structural requirements for `position: sticky` to work:
- The scrolling ancestor must have `overflow: auto` (or `scroll`) and a bounded height (e.g. `flex: 1; min-height: 0` in a flex column) — this is the container the composer docks *within*.
- No ancestor between the composer and the scrolling container may set `overflow: hidden`, `transform`, `filter`, or `contain` — any of those creates a new containing block and breaks the sticky calculation.
- The composer must be the **last element** in the scrollable content flow (after the message/document content), so its natural position is at the bottom.
- `bottom: 0` is relative to the scrolling container's padding box — if the scroll container itself has padding, account for it (see the `margin-bottom` / `padding-bottom` trick above, needed here because the padding lives on a nested wrapper, not on the scroll container itself).

## Notes / non-goals
- Do not implement this with `position: fixed` + JS scroll math — it's unnecessary and won't correctly scope to "bottom of panel" vs "bottom of viewport" as cleanly as sticky does.
- The composer's own auto-grow (textarea resizing to fit *user-typed* input) is a separate, orthogonal concern already handled by the existing `resize: vertical` textarea in the reference — not part of this handoff.
- No bottom-padding compensation for underlying content is included — the requester said they'd handle that spacing themselves in the real codebase.
